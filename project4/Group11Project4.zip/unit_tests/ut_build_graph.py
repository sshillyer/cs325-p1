from tsp_helper_functions import *

# Quick test
graph_ex1 = build_graph_from_file("provided/tsp_example_1.txt")
print(graph_ex1)
graph_ex1.print_matrix()